#include "stm32f10x.h" 
#include "bsp_usart.h"
#include "bsp_mp3.h"

//λ������,ʵ��51 sbit���ƿ��ƹ���
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C 
#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C 
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C 
 
#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808 
#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08 
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 


u8 home;
void open(void);
void close(void);
void stop(void);
void fan(void);
void USART1_IRQHandler(void);
void Motor_GPIO_Cofig(void);

int main(void)
{
	MP3_GPIO_Cofig();
	while(1)
	{
		MP3_1();
	}
}

void USART1_IRQHandler(void)
{
//	uint8_t temp;
//	if(USART_GetITStatus(USART1, USART_IT_RXNE)==1)
	if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE)==1)
	{
		home=USART_ReceiveData(USART1);
//		USART_SendData(USART1, home);
		switch(home)
	 {
		 case '1':open();
		          break;
		 case '2':close();
		          break;
		 default:stop();
		        
	 }
	}
}

void Motor_GPIO_Cofig()
{
	//�����ṹ��
	GPIO_InitTypeDef Motor_GPIO_Init;
	//����GPIO_APB2ʹ�ܣ���ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	//����ģʽ_CRL
	Motor_GPIO_Init.GPIO_Mode=GPIO_Mode_Out_PP;
	//��������_CRL
	Motor_GPIO_Init.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_5|GPIO_Pin_6;
	//���������ٶ�_CRL
	Motor_GPIO_Init.GPIO_Speed=GPIO_Speed_50MHz;
	//��ʼ��GPIOB
	GPIO_Init(GPIOB, &Motor_GPIO_Init);
}

void open()
{
	PBout(0)=1;
  PBout(1)=0;
}
void close()
{
	PBout(0)=0;
  PBout(1)=1;
}
void stop()
{
	PBout(0)=0;
  PBout(1)=0;
	PBout(5)=0;
  PBout(6)=0;
}

void fan()
{
	PBout(5)=0;
  PBout(6)=1;
}

