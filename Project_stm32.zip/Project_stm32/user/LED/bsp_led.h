#ifndef _bsp_led_h

#include "stm32f10x.h" 

#define _bsp_led_h

void LED_GPIO_Cofig(void);

#endif
