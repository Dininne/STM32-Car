#ifndef _bsp_mp3_h

#include "stm32f10x.h" 

#define _bsp_mp3_h

void MP3_GPIO_Cofig(void);
void Clear(void);
void MP3_1(void);
void MP3_2(void);
void MP3_3(void);
void MP3_4(void);
void MP3_5(void);
void MP3_6(void);

#endif
