#ifndef _bsp_co_h

#include "stm32f10x.h" 

#define _bsp_co_h

void CO_GPIO_Cofig(void);
uint8_t Scanf(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);

#endif
