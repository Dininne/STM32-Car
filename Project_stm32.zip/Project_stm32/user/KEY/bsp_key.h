#ifndef _bsp_key_h

#include "stm32f10x.h" 

#define _bsp_key_h

void KEY_GPIO_Cofig(void);

uint8_t Key_Scanf(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);

#endif
