#ifndef _bsp_exti_h

#include "stm32f10x.h" 

#define _bsp_exti_h

void EXTI_GPIO_Cofig(void);
void EXTI_NVIC_Cofig(void);

#endif
