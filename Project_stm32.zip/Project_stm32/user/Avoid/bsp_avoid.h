#ifndef _bsp_avoid_h

#include "stm32f10x.h" 

#define _bsp_avoid_h

void Avoid_GPIO_Cofig(void);

#endif
