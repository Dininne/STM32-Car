#ifndef _bsp_systick_h

#define _bsp_systick_h

#include "stm32f10x.h" 
#include "core_cm3.h" 

void systick_delay_us(uint32_t us);
void systick_delay_ms(uint32_t ms);

#endif
