#ifndef _bsp_usart_h

#include "stm32f10x.h" 

#define _bsp_usart_h

void USART_NVIC_Cofig(void);
void USART2_NVIC_Cofig(void);
void Usart_Cofig(void);
void Usart2_Cofig(void);

void SendByte(USART_TypeDef* pUSARTx,uint8_t data);
void Send_TwoByte(USART_TypeDef* pUSARTx,uint16_t data);
void Send_Array(USART_TypeDef* pUSARTx,uint8_t *array,uint8_t num);
void Send_Str(USART_TypeDef* pUSARTx,char *str);
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);


#endif
